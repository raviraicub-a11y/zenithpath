import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const q = sp.get("q")?.trim() || "";
  const trash = sp.get("trash") === "true";
  const status = sp.get("status") || undefined;
  const priority = sp.get("priority") || undefined;

  const leads = await prisma.lead.findMany({
    where: {
      deletedAt: trash ? { not: null } : null,
      ...(status ? { status: status as any } : {}),
      ...(priority ? { priority: priority as any } : {}),
      ...(q ? { OR: [
        { name: { contains: q, mode: "insensitive" } },
        { phone: { contains: q, mode: "insensitive" } },
        { city: { contains: q, mode: "insensitive" } },
        { email: { contains: q, mode: "insensitive" } }
      ] } : {})
    },
    include: { activities: { orderBy: { createdAt: "desc" }, take: 12 }, followups: { orderBy: { dueAt: "asc" }, take: 8 } },
    orderBy: { updatedAt: "desc" }
  });
  return NextResponse.json(leads);
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  if (!body.name || !body.phone) return NextResponse.json({ error: "Name and phone are required" }, { status: 400 });

  const lead = await prisma.lead.create({
    data: {
      name: body.name, phone: body.phone, whatsapp: body.whatsapp || body.phone,
      email: body.email || null, city: body.city || null, state: body.state || null,
      source: body.source || "Manual", campaign: body.campaign || null,
      assignedTo: body.assignedTo || null, priority: body.priority || "WARM",
      status: body.status || "NOT_CALLED", feedback: body.feedback || null
    }
  });

  await prisma.activity.create({ data: { leadId: lead.id, type: "SYSTEM", title: "Lead created", body: "New lead added to Zenithpath CRM" } });
  return NextResponse.json(lead, { status: 201 });
}
