import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(_: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const lead = await prisma.lead.findUnique({ where: { id }, include: { activities: { orderBy: { createdAt: "desc" } }, followups: { orderBy: { dueAt: "asc" } } } });
  if (!lead) return NextResponse.json({ error: "Lead not found" }, { status: 404 });
  return NextResponse.json(lead);
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const body = await req.json();
  const old = await prisma.lead.findUnique({ where: { id } });
  if (!old) return NextResponse.json({ error: "Lead not found" }, { status: 404 });

  const lead = await prisma.lead.update({
    where: { id },
    data: {
      name: body.name, phone: body.phone, whatsapp: body.whatsapp, email: body.email,
      city: body.city, state: body.state, source: body.source, campaign: body.campaign,
      company: body.company, occupation: body.occupation, budget: body.budget,
      houseType: body.houseType, roofType: body.roofType, bill: body.bill,
      aadhar: body.aadhar, bijliCopy: body.bijliCopy, addressProof: body.addressProof,
      bankDetails: body.bankDetails, status: body.status, priority: body.priority,
      feedback: body.feedback, assignedTo: body.assignedTo,
      nextFollowup: body.nextFollowup ? new Date(body.nextFollowup) : null,
      lastContactAt: body.lastContactAt ? new Date(body.lastContactAt) : undefined
    }
  });

  if (body.status && body.status !== old.status) {
    await prisma.activity.create({ data: { leadId: id, type: "STATUS_CHANGE", title: "Status changed", body: `${old.status} → ${body.status}` } });
  }
  return NextResponse.json(lead);
}

export async function DELETE(_: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const lead = await prisma.lead.update({ where: { id }, data: { deletedAt: new Date() } });
  await prisma.activity.create({ data: { leadId: id, type: "SYSTEM", title: "Lead moved to Trash", body: "Soft deleted; it can be restored." } });
  return NextResponse.json(lead);
}
