import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function POST(_: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const lead = await prisma.lead.update({ where: { id }, data: { deletedAt: null } });
  await prisma.activity.create({ data: { leadId: id, type: "SYSTEM", title: "Lead restored", body: "Lead restored from Trash." } });
  return NextResponse.json(lead);
}
