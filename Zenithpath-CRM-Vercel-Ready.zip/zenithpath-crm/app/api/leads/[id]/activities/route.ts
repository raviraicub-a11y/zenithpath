import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const body = await req.json();
  const type = body.type || "NOTE";
  const activity = await prisma.activity.create({ data: { leadId: id, type, title: body.title || type, body: body.body || null } });
  if (type === "CALL" || type === "WHATSAPP") await prisma.lead.update({ where: { id }, data: { lastContactAt: new Date() } });
  return NextResponse.json(activity, { status: 201 });
}
