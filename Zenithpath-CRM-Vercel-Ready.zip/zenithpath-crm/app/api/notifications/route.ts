import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const now = new Date();
  const soon = new Date(now.getTime() + 24*60*60*1000);
  const overdue = await prisma.followUp.findMany({ where: { completedAt: null, dueAt: { lt: now } }, include: { lead: true }, orderBy: { dueAt: "asc" }, take: 20 });
  const upcoming = await prisma.followUp.findMany({ where: { completedAt: null, dueAt: { gte: now, lte: soon } }, include: { lead: true }, orderBy: { dueAt: "asc" }, take: 20 });
  return NextResponse.json({ overdue, upcoming, count: overdue.length + upcoming.length });
}
