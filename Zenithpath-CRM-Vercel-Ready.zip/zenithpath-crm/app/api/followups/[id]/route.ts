import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
export async function PATCH(_: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const f = await prisma.followUp.update({ where: { id }, data: { completedAt: new Date() } });
  return NextResponse.json(f);
}
