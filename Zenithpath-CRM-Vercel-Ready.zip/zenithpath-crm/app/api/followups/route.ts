import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const rows = await prisma.followUp.findMany({ where: { completedAt: null }, include: { lead: true }, orderBy: { dueAt: "asc" }, take: 100 });
  return NextResponse.json(rows);
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const f = await prisma.followUp.create({ data: { leadId: body.leadId, dueAt: new Date(body.dueAt), note: body.note || null } });
  await prisma.lead.update({ where: { id: body.leadId }, data: { nextFollowup: new Date(body.dueAt), status: "FOLLOW_UP" } });
  await prisma.activity.create({ data: { leadId: body.leadId, type: "FOLLOW_UP", title: "Follow-up scheduled", body: body.note || new Date(body.dueAt).toLocaleString("en-IN") } });
  return NextResponse.json(f, { status: 201 });
}
