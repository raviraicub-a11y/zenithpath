import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
export async function GET() {
  const active = { deletedAt: null };
  const [total, notCalled, interested, converted, hot, trash, followups] = await Promise.all([
    prisma.lead.count({ where: active }),
    prisma.lead.count({ where: { ...active, status: "NOT_CALLED" } }),
    prisma.lead.count({ where: { ...active, status: { in: ["INTERESTED","FOLLOW_UP","SITE_VISIT","QUOTATION"] } } }),
    prisma.lead.count({ where: { ...active, status: "CONVERTED" } }),
    prisma.lead.count({ where: { ...active, priority: "HOT" } }),
    prisma.lead.count({ where: { deletedAt: { not: null } } }),
    prisma.followUp.count({ where: { completedAt: null } })
  ]);
  return NextResponse.json({ total, notCalled, interested, converted, hot, trash, followups });
}
