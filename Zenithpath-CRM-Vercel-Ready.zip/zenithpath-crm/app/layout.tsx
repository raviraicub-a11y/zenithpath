import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Zenithpath CRM",
  description: "Premium lead, follow-up and sales CRM by Zenithpath"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}
