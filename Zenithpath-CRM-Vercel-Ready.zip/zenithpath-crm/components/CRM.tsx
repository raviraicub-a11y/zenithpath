 "use client";
import { useEffect, useMemo, useState } from "react";
import { Bell, CalendarClock, CheckCircle2, ChevronRight, CircleUserRound, Download, FilePlus2, LayoutDashboard, MessageCircle, Phone, Plus, RefreshCw, Search, Settings, Trash2, Undo2, Users, X, StickyNote } from "lucide-react";

type Lead = any;
const statusLabels: Record<string,string> = {NOT_CALLED:"Not Called",RINGING:"Ringing / No Answer",SWITCHED_OFF:"Switched Off",INTERESTED:"Connected - Interested",NOT_INTERESTED:"Connected - Not Interested",FOLLOW_UP:"Follow-up Scheduled",SITE_VISIT:"Site Visit Done",QUOTATION:"Quotation Shared",CONVERTED:"Converted",DROPPED:"Dropped"};
const priorityLabels: Record<string,string> = {HOT:"Hot",WARM:"Warm",COLD:"Cold"};

function badgeClass(s:string){if(["CONVERTED","INTERESTED"].includes(s))return"badge b-green";if(["FOLLOW_UP","SITE_VISIT","QUOTATION","WARM"].includes(s))return"badge b-orange";if(["DROPPED","NOT_INTERESTED","HOT"].includes(s))return"badge b-red";return"badge b-blue"}
function initials(n:string){return (n||"?").split(" ").slice(0,2).map(x=>x[0]).join("").toUpperCase()}
function fmt(d:any){return d?new Date(d).toLocaleString("en-IN",{day:"2-digit",month:"short",hour:"2-digit",minute:"2-digit"}):"—"}

export default function CRM(){
 const [leads,setLeads]=useState<Lead[]>([]), [stats,setStats]=useState<any>({}), [q,setQ]=useState(""), [filter,setFilter]=useState("all");
 const [trash,setTrash]=useState(false), [selected,setSelected]=useState<Lead|null>(null), [tab,setTab]=useState("dashboard"), [loading,setLoading]=useState(true), [toast,setToast]=useState("");
 const [notifications,setNotifications]=useState<any>({count:0,overdue:[],upcoming:[]});

 async function load(){
  setLoading(true);
  const params=new URLSearchParams(); if(q)params.set("q",q); if(trash)params.set("trash","true");
  if(filter!=="all") params.set("status",filter);
  const [l,s,n]=await Promise.all([fetch("/api/leads?"+params).then(r=>r.json()),fetch("/api/dashboard").then(r=>r.json()),fetch("/api/notifications").then(r=>r.json())]);
  setLeads(l);setStats(s);setNotifications(n);setLoading(false);
 }
 useEffect(()=>{load()},[q,filter,trash]);
 function notify(t:string){setToast(t);setTimeout(()=>setToast(""),2200)}
 async function api(url:string,method="POST",body?:any){const r=await fetch(url,{method,headers:{"Content-Type":"application/json"},body:body?JSON.stringify(body):undefined});if(!r.ok)throw new Error((await r.json()).error||"Request failed");return r.json()}
 async function create(){
  const x=await api("/api/leads","POST",{name:"New Lead",phone:"",source:"Manual",priority:"WARM"});
  notify("Lead created");setSelected(x);load();
 }
 async function saveLead(data:any){
  const x=await api(`/api/leads/${data.id}`,"PATCH",data);setSelected(x);notify("Lead saved");load();
 }
 async function activity(type:string,title:string,body:string){
  if(!selected)return;
  await api(`/api/leads/${selected.id}/activities`,"POST",{type,title,body});notify(title); 
  const fresh=await fetch(`/api/leads/${selected.id}`).then(r=>r.json());setSelected(fresh);load();
 }
 async function trashLead(){if(!selected)return;await api(`/api/leads/${selected.id}`,"DELETE");setSelected(null);notify("Moved to Trash");load()}
 async function restore(id:string){await api(`/api/leads/${id}/restore`);notify("Lead restored");load()}
 function exportCSV(){
  const rows=[["Name","Phone","WhatsApp","City","Source","Status","Priority","Assigned","Next Follow-up"],...leads.map(l=>[l.name,l.phone,l.whatsapp,l.city,l.source,statusLabels[l.status],priorityLabels[l.priority],l.assignedTo,l.nextFollowup])];
  const csv=rows.map(r=>r.map(v=>`"${String(v??"").replaceAll('"','""')}"`).join(",")).join("\n");const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([csv],{type:"text/csv"}));a.download="zenithpath-crm-export.csv";a.click();URL.revokeObjectURL(a.href);
 }
 const filters=[["all","All Leads"],["NOT_CALLED","Not Called"],["INTERESTED","Interested"],["FOLLOW_UP","Follow-up"],["QUOTATION","Quotation"],["CONVERTED","Converted"]];
 return <div className="shell">
  <header className="topbar"><div className="brand"><div className="brandmark">Z</div><div><h1>Zenithpath CRM</h1><span>Lead Intelligence • Sales • Follow-up</span></div></div><div className="top-actions"><input className="search" value={q} onChange={e=>setQ(e.target.value)} placeholder="Search name, phone, city, email…" /><button className="btn" onClick={()=>setTab("notifications")}><Bell size={15}/>{notifications.count>0&&<b>{notifications.count}</b>}</button><button className="btn primary" onClick={create}><Plus size={15}/> Add Lead</button></div></header>
  <div className="layout">
   <aside className="sidebar"><div className="nav-title">Workspace</div><div className="nav">
    <button className={tab==="dashboard"?"active":""} onClick={()=>{setTab("dashboard");setTrash(false)}}><LayoutDashboard size={16}/><span>Dashboard</span></button>
    <button className={tab==="leads"?"active":""} onClick={()=>{setTab("leads");setTrash(false)}}><Users size={16}/><span>All Leads</span></button>
    <button className={tab==="followups"?"active":""} onClick={()=>setTab("followups")}><CalendarClock size={16}/><span>Follow-ups</span></button>
    <button className={tab==="notifications"?"active":""} onClick={()=>setTab("notifications")}><Bell size={16}/><span>Notifications</span></button>
    <button className={trash?"active":""} onClick={()=>{setTrash(true);setTab("leads")}}><Trash2 size={16}/><span>Trash</span></button>
   </div><div className="nav-title" style={{marginTop:24}}>Tools</div><div className="nav"><button onClick={exportCSV}><Download size={16}/><span>Export CSV</span></button><button onClick={load}><RefreshCw size={16}/><span>Refresh</span></button></div><div className="side-foot"><b>Zenithpath</b><br/>Premium CRM workspace<br/>Built for fast sales follow-up.</div></aside>
   <main>
    {tab==="notifications"?<Notifications data={notifications} onDone={load}/>:tab==="followups"?<Followups data={notifications} onDone={load} onOpen={(l:any)=>setSelected(l)}/>:<><div className="page-head"><div><div className="eyebrow">{trash?"Recycle Bin":"Sales Workspace"}</div><h2 className="page-title">{trash?"Deleted Leads":"Lead Command Center"}</h2><p className="page-sub">{trash?"Restore deleted records or keep your pipeline clean.":"Every lead, call, WhatsApp touchpoint and follow-up in one place."}</p></div><div><button className="btn primary" onClick={create}><FilePlus2 size={15}/> New Lead</button></div></div>
     <div className="stats"><Stat label="Total Leads" value={stats.total}/><Stat label="Not Called" value={stats.notCalled}/><Stat label="In Progress" value={stats.interested}/><Stat label="Converted" value={stats.converted}/><Stat label="Follow-ups" value={stats.followups}/></div>
     <div className="card toolbar"><div className="filters">{filters.map(f=><button key={f[0]} className={"chip "+(filter===f[0]?"active":"")} onClick={()=>setFilter(f[0])}>{f[1]}</button>)}</div><span style={{fontSize:11,color:"#7b8799",fontWeight:700}}>{leads.length} records</span></div>
     <div className="card table"><div className="thead"><div>Lead</div><div>Contact</div><div>Location</div><div>Status</div><div>Priority</div><div>Action</div></div>{loading?<div className="empty">Loading CRM…</div>:leads.length===0?<div className="empty">No leads found.</div>:leads.map(l=><div className="tr" key={l.id}><div onClick={()=>setSelected(l)} style={{cursor:"pointer"}}><div className="name">{l.name}</div><div className="sub">{l.source||"Manual"} {l.campaign?`• ${l.campaign}`:""}</div></div><div><div>{l.phone}</div><div className="sub">{l.whatsapp||"No WhatsApp"}</div></div><div>{l.city||"—"}<div className="sub">{l.state||""}</div></div><div><span className={badgeClass(l.status)}>{statusLabels[l.status]}</span></div><div><span className={badgeClass(l.priority)}>{priorityLabels[l.priority]}</span></div><div className="actions">{trash?<button className="icon" title="Restore" onClick={()=>restore(l.id)}><Undo2 size={14}/></button>:<><a className="icon" href={`tel:${l.phone}`} title="Call"><Phone size={14}/></a><a className="icon" href={`https://wa.me/${String(l.whatsapp||l.phone).replace(/\D/g,"")}`} target="_blank" title="WhatsApp"><MessageCircle size={14}/></a><button className="icon" title="Open" onClick={()=>setSelected(l)}><ChevronRight size={15}/></button></>}</div></div>)}</div>
    </>}
   </main>
  </div>
  {selected&&<LeadDrawer lead={selected} onClose={()=>setSelected(null)} onSave={saveLead} onActivity={activity} onDelete={trashLead}/>}
  {toast&&<div className="toast">{toast}</div>}
 </div>
}

function Stat({label,value}:{label:string,value:any}){return <div className="card stat"><div className="stat-label">{label}</div><div className="stat-value">{value??0}</div><div className="stat-note">Live database metric</div></div>}

function LeadDrawer({lead,onClose,onSave,onActivity,onDelete}:{lead:Lead,onClose:()=>void,onSave:(x:any)=>void,onActivity:(a:string,b:string,c:string)=>void,onDelete:()=>void}){
 const [f,setF]=useState({...lead});const set=(k:string,v:any)=>setF((x:any)=>({...x,[k]:v}));
 const save=()=>onSave(f);
 return <><div className="drawer-back" onClick={onClose}/><aside className="drawer"><div className="drawer-head"><div className="profile"><div className="avatar">{initials(f.name)}</div><div><div style={{fontSize:16,fontWeight:850}}>{f.name}</div><div style={{fontSize:11,color:"#748095"}}>{f.id} • {f.source||"Manual"}</div></div></div><button className="icon" onClick={onClose}><X size={16}/></button></div>
 <div className="drawer-body"><div className="quick"><a className="btn success" href={`tel:${f.phone}`} onClick={()=>onActivity("CALL","Call initiated",`Called ${f.phone}`)}><Phone size={14}/> Call</a><a className="btn success" href={`https://wa.me/${String(f.whatsapp||f.phone).replace(/\D/g,"")}`} target="_blank" onClick={()=>onActivity("WHATSAPP","WhatsApp opened",`WhatsApp: ${f.whatsapp||f.phone}`)}><MessageCircle size={14}/> WhatsApp</a><button className="btn" onClick={()=>onActivity("NOTE","Note added","Quick note added from lead profile.")}><StickyNote size={14}/> Note</button><button className="btn" onClick={()=>onActivity("FOLLOW_UP","Follow-up touchpoint","Follow-up action recorded.")}><CalendarClock size={14}/> Follow-up</button></div>
 <div className="section"><h3>Lead profile</h3><div className="grid2">{[["name","Full name"],["phone","Phone"],["whatsapp","WhatsApp"],["email","Email"],["city","City"],["state","State"],["source","Source"],["campaign","Campaign"],["company","Company"],["occupation","Occupation"],["budget","Budget"],["assignedTo","Assigned To"]].map(([k,l])=><div className="field" key={k}><label>{l}</label><input value={f[k]||""} onChange={e=>set(k,e.target.value)}/></div>)}</div></div>
 <div className="section"><h3>Pipeline</h3><div className="grid2"><div className="field"><label>Status</label><select value={f.status} onChange={e=>set("status",e.target.value)}>{Object.entries(statusLabels).map(([k,v])=><option key={k} value={k}>{v}</option>)}</select></div><div className="field"><label>Priority</label><select value={f.priority} onChange={e=>set("priority",e.target.value)}><option value="HOT">Hot</option><option value="WARM">Warm</option><option value="COLD">Cold</option></select></div><div className="field"><label>Next Follow-up</label><input type="datetime-local" value={f.nextFollowup?new Date(f.nextFollowup).toISOString().slice(0,16):""} onChange={e=>set("nextFollowup",e.target.value)}/></div><div className="field"><label>Bill / Budget detail</label><input value={f.bill||""} onChange={e=>set("bill",e.target.value)}/></div></div></div>
 <div className="section"><h3>Documents & qualification</h3><div className="grid2">{[["aadhar","Aadhaar"],["bijliCopy","Electricity Bill"],["addressProof","Address Proof"],["bankDetails","Bank Details"],["houseType","House Type"],["roofType","Roof Type"]].map(([k,l])=><div className="field" key={k}><label>{l}</label><input value={f[k]||""} onChange={e=>set(k,e.target.value)}/></div>)}</div></div>
 <div className="section"><h3>Feedback / notes</h3><div className="field"><textarea value={f.feedback||""} onChange={e=>set("feedback",e.target.value)}/></div></div>
 <div className="section"><h3>Activity timeline</h3><div className="timeline">{(f.activities||[]).map((a:any)=><div className="event" key={a.id}><strong>{a.title}</strong><div className="sub">{fmt(a.createdAt)}</div>{a.body&&<p>{a.body}</p>}</div>)}</div></div>
 </div><div className="drawer-footer"><button className="btn danger" onClick={onDelete}><Trash2 size={14}/> Delete</button><button className="btn" onClick={onClose}>Cancel</button><button className="btn primary" onClick={save}><CheckCircle2 size={14}/> Save Changes</button></div></aside></>
}

function Notifications({data,onDone}:{data:any,onDone:()=>void}){return <div><div className="page-head"><div><div className="eyebrow">Smart Alerts</div><h2 className="page-title">Notifications</h2><p className="page-sub">Overdue and upcoming follow-ups that need attention.</p></div></div><div className="card" style={{padding:16}}><h3 style={{fontSize:13}}>Overdue</h3>{data.overdue?.length?data.overdue.map((x:any)=><div className="event" key={x.id} style={{marginBottom:7}}><b>{x.lead.name}</b><div className="sub">{fmt(x.dueAt)} • {x.note||"Follow-up due"}</div></div>):<div className="empty">No overdue follow-ups.</div>}<h3 style={{fontSize:13,marginTop:22}}>Next 24 hours</h3>{data.upcoming?.length?data.upcoming.map((x:any)=><div className="event" key={x.id} style={{marginBottom:7}}><b>{x.lead.name}</b><div className="sub">{fmt(x.dueAt)} • {x.note||"Upcoming follow-up"}</div></div>):<div className="empty">No upcoming alerts.</div>}</div></div>}

function Followups({data,onDone,onOpen}:{data:any,onDone:()=>void,onOpen:(l:any)=>void}){return <div><div className="page-head"><div><div className="eyebrow">Task Queue</div><h2 className="page-title">Follow-up Manager</h2><p className="page-sub">Keep every promise, callback and sales touchpoint visible.</p></div></div><div className="card" style={{padding:15}}>{[...(data.overdue||[]),...(data.upcoming||[])].map((x:any)=><div className="tr" key={x.id} style={{gridTemplateColumns:"1.6fr 1fr 1.8fr auto",borderTop:"0",borderBottom:"1px solid var(--border)"}}><div onClick={()=>onOpen(x.lead)} style={{cursor:"pointer"}}><b>{x.lead.name}</b><div className="sub">{x.lead.phone}</div></div><div>{fmt(x.dueAt)}</div><div className="sub">{x.note||"Follow-up"}</div><button className="btn success" onClick={async()=>{await fetch(`/api/followups/${x.id}`,{method:"PATCH"});onDone()}}><CheckCircle2 size={14}/> Done</button></div>)}{!(data.overdue?.length||data.upcoming?.length)&&<div className="empty">No pending follow-ups.</div>}</div></div>}
