export const STATUS_OPTIONS = [
  ["NOT_CALLED", "Not Called"],
  ["RINGING", "Ringing / No Answer"],
  ["SWITCHED_OFF", "Switched Off"],
  ["INTERESTED", "Connected - Interested"],
  ["NOT_INTERESTED", "Connected - Not Interested"],
  ["FOLLOW_UP", "Follow-up Scheduled"],
  ["SITE_VISIT", "Site Visit Done"],
  ["QUOTATION", "Quotation Shared"],
  ["CONVERTED", "Converted"],
  ["DROPPED", "Dropped"]
] as const;

export const PRIORITY_OPTIONS = [
  ["HOT", "Hot"], ["WARM", "Warm"], ["COLD", "Cold"]
] as const;

export function waLink(num?: string | null) {
  if (!num) return "#";
  return `https://wa.me/${num.replace(/\D/g, "")}`;
}
