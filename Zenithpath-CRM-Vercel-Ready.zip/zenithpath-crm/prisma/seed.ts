import { PrismaClient } from "@prisma/client";
import seed from "./seed-leads.json";
const prisma = new PrismaClient();
async function main(){
  for(const x of seed as any[]){
    await prisma.lead.upsert({
      where:{externalId:String(x.id)},
      update:{name:x.name,phone:x.phone,whatsapp:x.whatsapp||x.phone,city:x.city,source:x.source,campaign:x.campaign,priority:x.priority==="Hot"?"HOT":x.priority==="Cold"?"COLD":"WARM"},
      create:{externalId:String(x.id),name:x.name,phone:x.phone,whatsapp:x.whatsapp||x.phone,city:x.city,source:x.source,campaign:x.campaign,priority:x.priority==="Hot"?"HOT":x.priority==="Cold"?"COLD":"WARM"}
    });
  }
  console.log(`Imported ${seed.length} supplied leads`);
}
main().finally(()=>prisma.$disconnect());
